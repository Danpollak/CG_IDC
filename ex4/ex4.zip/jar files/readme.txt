Add Jama-1.0.3.jar to your build path, this is the linear solver.
Add my-locomotive.jar to your build path if you don't want to use yours.