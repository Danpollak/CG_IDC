Place these java files in you ex3 project folder in their correct package.
If you don't want to overwrite your old java files, merge them.