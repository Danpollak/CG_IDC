The natives directory, the grass.jpg and the track.png textures and the ex4-complete.jar file
should be in the same directory in order to let the executble ex4-complete.jar file to run.